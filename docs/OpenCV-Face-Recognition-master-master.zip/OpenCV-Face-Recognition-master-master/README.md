# OpenCV-Face-Recognition
Real-time face recognition project with OpenCV and Python
<br><br>

<br>
<p><img src="https://github.com/Mjrovai/OpenCV-Face-Recognition/blob/master/FaceRecogBlock.png?raw=true"></p>
